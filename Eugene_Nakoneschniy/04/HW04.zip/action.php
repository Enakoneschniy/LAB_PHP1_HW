<?php
$city = $_POST['city'];
//echo "Ваш город: ", $city, "<br>";
if ($_POST['city'] == '')
	echo "Введите город, <a href='/05/'>Исправить</a>";
else
	echo "Ваш город: ", $city, "<br>";

?>
