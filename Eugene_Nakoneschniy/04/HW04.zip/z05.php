<?php
//Задача5//////////////
if(isset($_POST['submit'])){
			if ($_POST['age1'] == "")
			{
				
				header("Location: z05.html");
			}
			else
			{
				echo "Ваш возраст: ", $_POST['age1'];
			}
}
	

?>
