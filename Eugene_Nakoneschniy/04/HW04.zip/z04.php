<?php
//Задача4
echo "Привет,	", $_POST['u_name'],",	", $_POST['age'], "лет. <br>", "Твое сообщение: ", $_POST['message'];
?>