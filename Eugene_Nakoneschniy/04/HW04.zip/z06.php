<?php
$login = 'Dmitry';
$pass = '150388d';
if($_POST['password'] == $pass && $_POST['u_name'] == $login)
	echo "Acces Granted!!!";
else
	echo "Acces Denied!!! <a href='/05/z06.html'>Try again.</a>";

?>